class Prod():
    def __init__(self) -> None:
        self.host = 'www.youtwin.com.cn'
        self.username = 'root'
        self.passwd = 'Cabinda@9527'
        self.port=13306
        self.db= 'zjsgj'
        self.chart = 'utf8mb4'


class Test():

    def __init__(self) -> None:
        self.host = 'www.youtwin.com.cn'
        self.username = 'root'
        self.passwd = 'Cabinda@9527'
        self.port=13306
        self.db= 'zjsgj'
        self.chart = 'utf8mb4'
