import InsertApp


if __name__=='__main__':
    InsertApp.app.run(port=5555,debug=True)